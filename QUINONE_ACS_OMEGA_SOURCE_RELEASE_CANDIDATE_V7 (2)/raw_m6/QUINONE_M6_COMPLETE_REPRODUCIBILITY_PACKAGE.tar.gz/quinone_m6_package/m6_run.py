#!/usr/bin/env python3
"""M6 frozen alternative-method sensitivity campaign; no optimizations."""
import argparse,csv,hashlib,json,os,re,shutil,subprocess,sys,time
from pathlib import Path

SITES=[('Q0527_R0_SME1','BAQ'),('Q0298_R3_SME1','7-MeBAQ'),('Q0059_R0_SME3','BPAQ-C5'),('Q0528_R0_SME1','NPQ-control')]
ROOT=Path.home(); BASE=ROOT/'quinone_orca_marathon1'/'14_orca_marathon1'; M5=ROOT/'quinone_orca_marathon5'/'ORCA_MARATHON5_LEAN_V2'
OUT=ROOT/'quinone_m6_validation'; GEOM=OUT/'geometries'; RUNS=OUT/'jobs'
METHOD='PBE0 D4 ma-def2-TZVP SMD(Water) TightSCF DEFGRID3 NoAutoStart'
HARTREE_EV=27.211386245988

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def atomic_json(path,obj):
    tmp=path.with_suffix('.tmp');tmp.write_text(json.dumps(obj,indent=2)+'\n');tmp.replace(path)
def resolve_geometry(site,kind,state):
    parent=site.split('_')[0]
    if kind=='parent':
        return BASE/'runs'/f'{parent}__parent__c0__{state}'/'03_sp'/'start.xyz'
    if kind=='sme':
        return BASE/'runs'/f'{site}__c0__{state}'/'03_sp'/'start.xyz'
    return M5/'source_snapshot'/site/state/'full_accysome_selected.xyz'
def read_xyz(p):
    lines=p.read_text().splitlines(); n=int(lines[0].strip()); coords=[x.split() for x in lines[2:2+n]]
    if len(coords)!=n or any(len(x)<4 for x in coords):raise RuntimeError(f'Invalid XYZ: {p}')
    return n,lines

def orca_binary():
    v=os.environ.get('ORCA_BIN','');candidate=Path(v).expanduser() if v else None
    if candidate and candidate.is_file():return str(candidate.resolve())
    p=shutil.which('orca')
    if p:return str(Path(p).resolve())
    raise RuntimeError('ORCA not on PATH. Export ORCA_BIN=/absolute/path/to/orca')

def prepare():
    OUT.mkdir(exist_ok=True); GEOM.mkdir(exist_ok=True); RUNS.mkdir(exist_ok=True)
    records=[];errors=[]
    for site,label in SITES:
        for kind in ['parent','sme','accysome']:
            for state in ['neutral','reduced']:
                orig=resolve_geometry(site,kind,state)
                if not orig.is_file():errors.append(str(orig));continue
                n,_=read_xyz(orig)
                dest=GEOM/f'{site}__{kind}__{state}.xyz'; h=sha(orig)
                if dest.exists() and sha(dest)!=h:raise RuntimeError('Frozen geometry changed: '+str(dest))
                if not dest.exists():shutil.copyfile(orig,dest)
                charge,mult=(0,1) if state=='neutral' else (-1,2)
                records.append(dict(site=site,label=label,kind=kind,state=state,source=str(orig),xyz=str(dest),sha256=h,atoms=n,charge=charge,multiplicity=mult))
    if errors:
        atomic_json(OUT/'PREFLIGHT_FAILURE.json',{'missing':errors});raise RuntimeError('Missing source geometry; no calculations started. See PREFLIGHT_FAILURE.json')
    # Check each pair has same atom/element list and reasonable atom counts.
    for site,label in SITES:
        for kind in ['parent','sme','accysome']:
            pair=[x for x in records if x['site']==site and x['kind']==kind]
            elements=[]
            for rec in pair:
                _,lines=read_xyz(Path(rec['xyz']));elements.append(sorted(line.split()[0] for line in lines[2:]))
            if elements[0]!=elements[1]:raise RuntimeError('Different elemental stoichiometry between redox states: '+site+' '+kind)
    manifest=OUT/'M6_FROZEN_MANIFEST.json'
    plan={'purpose':'independent-method sensitivity of surrogate sign reversals; NOT experimental validation',
          'method':METHOD,'energy_conversion_Hartree_to_eV':HARTREE_EV,'cases':SITES,'job_count':len(records),
          'reference':'same parent, SME, AcCysOMe per quinone; each neutral and one-electron reduced',
          'statistical_unit':'quinone parent; 4 prespecified cases, 2 reversal cases and 2 controls',
          'no_expansion':True,'input_records':records}
    if manifest.exists():
        old=json.loads(manifest.read_text())
        if old!=json.loads(json.dumps(plan)):raise RuntimeError('Frozen plan changed; stopping without overwrite')
    else:atomic_json(manifest,plan)
    return records

def make_input(rec):
    folder=RUNS/f"{rec['site']}__{rec['kind']}__{rec['state']}";folder.mkdir(exist_ok=True)
    dest=folder/'input.xyz';source=Path(rec['xyz']);
    if not dest.exists():shutil.copyfile(source,dest)
    if sha(dest)!=rec['sha256']:raise RuntimeError('Job geometry changed: '+str(dest))
    content=(f'! {METHOD}\n%pal nprocs 6 end\n%maxcore 1200\n%scf\n MaxIter 300\n AutoTRAH true\nend\n* xyzfile {rec["charge"]} {rec["multiplicity"]} input.xyz\n')
    inp=folder/'job.inp'
    if inp.exists() and inp.read_text()!=content:raise RuntimeError('Frozen input changed: '+str(inp))
    if not inp.exists():inp.write_text(content)
    return folder

def get_energy(path):
    if not path.exists():return None
    s=path.read_text(errors='replace')
    if 'ORCA TERMINATED NORMALLY' not in s:return None
    es=re.findall(r'FINAL SINGLE POINT ENERGY\s+(-?\d+\.\d+)',s)
    if not es:return None
    return float(es[-1])

def summarize(records):
    rows=[];energy={}
    for r in records:
        d=RUNS/f"{r['site']}__{r['kind']}__{r['state']}"; e=get_energy(d/'job.out')
        rows.append({**{k:r[k] for k in ['site','label','kind','state','sha256','atoms','charge','multiplicity']},'energy_hartree':e if e is not None else '', 'status':'PASS' if e is not None else 'PENDING_OR_FAILED'})
        if e is not None:energy[(r['site'],r['kind'],r['state'])]=e
    with (OUT/'M6_ENERGIES.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=rows[0].keys());w.writeheader();w.writerows(rows)
    shifts=[]
    for site,label in SITES:
        def red(kind):
            return energy[(site,kind,'reduced')]-energy[(site,kind,'neutral')]
        if all((site,k,s) in energy for k in ['parent','sme','accysome'] for s in ['neutral','reduced']):
            parent=red('parent');a=(red('sme')-parent)*HARTREE_EV;b=(red('accysome')-parent)*HARTREE_EV
            shifts.append({'site':site,'label':label,'sme_shift_eV':a,'accysome_shift_eV':b,'full_minus_sme_eV':b-a,'sme_accysome_sign_reversal':(a*b<0)})
    if shifts:
        with (OUT/'M6_METHOD_SENSITIVITY.csv').open('w',newline='') as f:
            w=csv.DictWriter(f,fieldnames=shifts[0].keys());w.writeheader();w.writerows(shifts)
    atomic_json(OUT/'M6_STATUS.json',{'completed':sum(x['status']=='PASS' for x in rows),'total':len(rows),'all_complete':all(x['status']=='PASS' for x in rows),'method':METHOD,'shifts':shifts,'limitations':['Fixed geometries from original method; not full method-specific reoptimization','No direct experimental validation','Original M1 geometries use c0 reference; M3R ensemble vs single-conformer comparison requires separate interpretation']})

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--prepare-only',action='store_true');ap.add_argument('--max-jobs',type=int,default=24);args=ap.parse_args()
    records=prepare();orca=orca_binary() if not args.prepare_only else None
    for rec in records:make_input(rec)
    if args.prepare_only:
        summarize(records);print('PREFLIGHT OK; 24 frozen jobs prepared. No ORCA started.');return
    count=0
    for rec in records:
        folder=make_input(rec)
        if get_energy(folder/'job.out') is not None:continue
        if count>=args.max_jobs:break
        log=folder/'job.out';print(f'RUN {rec["site"]} {rec["kind"]} {rec["state"]}',flush=True)
        with log.open('w') as f:
            proc=subprocess.run([orca,str((folder/'job.inp').resolve())],cwd=folder,stdout=f,stderr=subprocess.STDOUT,check=False)
        count+=1;summarize(records)
        if proc.returncode!=0 or get_energy(log) is None:
            print('STOP: ORCA failed; see '+str(log),flush=True);sys.exit(2)
    summarize(records);print('M6 run checkpoint complete; consult M6_STATUS.json',flush=True)
if __name__=='__main__':main()
