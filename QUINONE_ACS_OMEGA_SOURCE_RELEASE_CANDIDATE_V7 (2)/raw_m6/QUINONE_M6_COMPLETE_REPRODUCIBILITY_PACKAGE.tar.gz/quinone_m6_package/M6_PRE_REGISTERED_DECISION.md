# Frozen M6 decision rules

Objective: Test alternative-functional robustness of surrogate sign reversals with a prespecified four-case set; negative results are publishable as sensitivity limitations, not silently replaced.

Cases: Q0527_R0_SME1 (BAQ), Q0298_R3_SME1 (7-MeBAQ), Q0059_R0_SME3 (BPAQ C5), Q0528_R0_SME1 (NPQ control).

Primary report: M6 sign of SMe ΔΔE, AcCysOMe ΔΔE and difference; compare direction with M1/M3R while distinguishing fixed conformer from ensemble. Count the two prespecified reversal cases retaining reversal. No reclassification threshold tuning, no claim of independent experimental corroboration. Report all four cases including failures and quantitative deltas, not just favorable ones.

Freeze: PBE0 D4, ma-def2-TZVP, aqueous SMD; 6 cores, 1200 MB per core, TightSCF DEFGRID3 NoAutoStart, 300 SCF iterations AutoTRAH. Parent and SMe from completed M1 production geometries, full cysteine conjugate from M5 selected snapshot. 24 SP, no geometry optimizations.

Caution: Only compare chemically matched neutral (0,1) and anionic (−1,2) states. Electronic energies omit proton/electron chemical potentials (differences cancel only under consistent thermodynamic construction). Results test alternative DFT method sensitivity of electronic energies at frozen geometries, not experimentally measured redox potentials or cellular toxicity.

Stop rule: 24 planned jobs maximum. Any source missing, formula mismatch, method/input unexpected changes or first ORCA abnormal termination stops automatically; no automatic rescue escalation. Human review decides whether a defect is worth repairing.
