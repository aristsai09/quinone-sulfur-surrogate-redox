M6 FINAL REPRODUCIBILITY PACKAGE - 2026-10-18
24 prespecified ORCA PBE0-D4 fixed-geometry single points.
Original review archive plus all 24 input.xyz geometries and m6_run.py.
24/24 ORCA normal terminations and SCF convergences independently verified.
24/24 geometry SHA256 hashes agree with M6_ENERGIES.csv.
Original M1-M5 data and referenced source geometries are NOT included; this archive reproduces M6 single points only.
No experimental electrochemical validation; not a toxicity mechanism demonstration.
No M7 recommended.
